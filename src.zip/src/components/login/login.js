import React ,{useState} from "react";
import  "./login.css";
import axios from "axios"
// import { useHistory } from "react-router-dom"


const Login=()=>{
    // const history=useHistory()
    const [user,setUser]=useState({
        email:"",
        password:""
      })
  
      const handleChange= e => {
        const {name , value} =e.target
        setUser({
            ...user,
            [name]:value
        })
    }

    const login=()=>{
        const { email, password }= user
        if(email && password)
        {
            
            if(password.length<8){
                alert("please enter the correct password")
            }else{
            axios.post("http://localhost:9002/login",{user})
            .then( res=> alert(res.data.message))
            }
        }else{
            alert("invalid input")
        }

    }
    
    return(
        <div className="login">
            <div class="wrapper">
      <div class="title">Login Form</div>
      <div className="formm">
        <div class="field">
          <input type="text" required/>
          <label>Email Address</label>
        </div>
        <div class="field">
          <input type="password" required/>
          <label>Password</label>
        </div>
        <div class="content">
          <div class="pass-link"><a href="#">Forgot password?</a></div>
        </div>
        <div class="field">
          <input type="submit" value="Login"/>
        </div>
        <div class="signup-link">Not a member? <a href="http://localhost:3000/login">Signup now</a></div>
        </div>
    </div>
        </div>
    )

}

export default Login
