
import React from "react";
import  "./dataholder.css";

const Dataholder=()=>{
    return(
        <div className="dataholder">
            <div className="alig-f filter-data">
                    <div className="input-style">
                            <button type="button" class="btn btn-primary ppp">New Appointment</button>
                            <button type="button" class="btn btn-primary ppp">search patient</button>
                            <button type="button" class="btn btn-primary ppp">filter</button>
                            <button type="button" class="btn btn-primary ppp">settings</button>
                   </div>
            </div>
            <div className="alig-f data-table">

            </div> 
        </div>
    )

}

export default Dataholder