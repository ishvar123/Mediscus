import React from "react";
import  "./dashboard.css";
// import Dataholder from './components/dashboard/dataholder';
import Dataholder from "./dataholder";


const Dashboard=()=>{
    return(
        <div className="homepage">
            <div className="Dashboardtitle "> 
                    <h1>Clinic dashboard</h1>
            </div>
            <div className="Dashboardbody ">
                <div className="sidebar stylec">
                    <h2>Settings</h2>
                </div>
                <div className=" stylec stylec">
                <Dataholder/>
                </div>
            </div>
           
        </div>
        
    )

}



export default Dashboard
