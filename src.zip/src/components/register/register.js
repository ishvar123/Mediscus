// import React , {useState} from "react";
// import  "./register.css";
// import axios from "axios";
// // import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
// import useForm from '../../hooks/useForm';


// const Register=()=>{
//     // const [user,setUser]=useState({
//     //   fname:"",
//     //   mname:"",
//     //   lname:"",
//     //   email:"",
//     //   phone:"",
//     //   password:"",
//     //   reEnterPassword:"",
//     //   dob:"",
//     //   Regno:"",
//     //   gender:""
//     // })

//     // const handleChange= e => {
//     //     const {name , value} =e.target
//     //     console.log(user)
//     //     setUser({
//     //         ...user,
//     //         [name]:value
//     //     })
//     // }
    

//     const register=()=>{

//       const formLogin = () => {
//         console.log("Callback function when form is submitted!");
//         console.log("Form Values ", values);
//       }
//       const {handleChange, values,errors,handleSubmit} = useForm(formLogin);



//         // const {fname, lname, gender, email, phone, password ,Regno ,reEnterPassword, dob}= user
//         // console.log(user)
        
//       //   if(password.length<8){
//       //     // alert("please enter at lest 8 word password")
//       //     document.getElementById("passerror").innerHTML="please enter at lest 8 word password";
//       // }
//       // if((password !== reEnterPassword)){
//       //   // alert("password and reEnterPassword should be same")
//       //   document.getElementById("spasserror").innerHTML="both password should be same";

//       // }

//       //  if(phone){
//       //     var patter= /((\+*)((0[ -]*)*|((91 )*))((\d{12})+|(\d{10})+))|\d{5}([- ]*)\d{6}/; 
//       //     if(!(phone.match(patter))){
//       //          document.getElementById("perr").innerHTML="invalid phone number";
//       //     }
//       //   }
//       //   if(!phone){
//       //     document.getElementById("perr").innerHTML="phone number cannot be empty";
//       //   }



//       //     if(!fname){
//       //       document.getElementById("fnameerr").innerHTML="first name cannot be empty";
//       //     }
//       //     if(!lname){
//       //       document.getElementById("lnameerr").innerHTML="last name cannot be empty";
//       //     }
          



        
//       //   if(!password || !reEnterPassword)
//       //   {
//       //     document.getElementById("cpasserror").innerHTML="confirm password cannot be emplty";
//       //     document.getElementById("passerror").innerHTML="password cannot be emplty";
//       //   }

//       //   // if(Regno){
//       //   //   document.getElementsByClassName("numbersOnly").keyup(function () { 
//       //   //     this.value = this.value.replace(/[^0-9\.]/g,'');
//       //   // });
//       //   // }

//       //   if(email)
//       //   {
//       //     var validRegex = /^[a-zA-Z0-9.!#$%&'+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)$/;
//       //     if (email.match(validRegex)) {
//       //       // return true;
            
//       //     } else {
            
//       //     // alert("Invalid email address!");
//       //     document.getElementById("emailerror").innerHTML="Invalid email address!";
            
//       //     // return false;
            
//       //     }
//       //   }
//       //   else{
//       //     document.getElementById("emailerror").innerHTML="email address cannot be empty";
//       //   }
//       //   if(!Regno)
//       //   {
//       //     document.getElementById("Regnoerr").innerHTML="registration number cannot be empty";
//       //   }



//       //   if(dob){
//       //         let current = new Date();
//       //         let date = new Date(dob);
//       //         let ms1 = current.getTime();
//       //         let ms2 = date.getTime();
//       //         console.log(date)
//       //         if(ms2 > ms1)
//       //         {
//       //           // alert("please fill the past date")
                
//       //           document.getElementById("dateerror").innerHTML="please fill the past date";
//       //         }
//       //   }else{
//       //     document.getElementById("dateerror").innerHTML="date cannot be empty";
//       //   }

//         // if(fname && dob && lname && email && phone && Regno && password && reEnterPassword)
//         // {
//         //   console.log("result",password)
//         //   // if((password !== reEnterPassword)){
//         //   //   alert("password and reEnterPassword should be same")
//         //   // }
           
//         //     axios.post("http://localhost:9002/register",{user})
//         //     .then( res=> alert(res.data.message))
            
//         // }
//         // else{
//         //     alert("please fill all the required fields")
//         // }
//     }
//     return(
//       <form onSubmit={handleSubmit} className="form">
//        <div className="register">
//   <div className="container">
//     <div className="title">Doctor Registration</div>
//     <div className="content">
//       <div className="formm">
//         <div className="user-details">
//           <div className="input-box">
//             <span className="details">First Name <span className="text-danger font-weight-bold">*</span> </span>
//             <input type="text" name="fname" value={user.name} placeholder="Enter your Name" onChange={handleChange} required/>
//             <span id="fnameerr" className="text-danger font-weight-bold"></span>
//           </div>
//           <div className="input-box">
//             <span className="details">Middle Name</span>
//             <input type="text" name="mname" value={user.name} onChange={handleChange} placeholder="Enter your middle name"/>
      
//           </div>
//           <div className="input-box">
//             <span className="details">Last Name <span className="text-danger font-weight-bold">*</span></span>
//             <input type="text" name="lname" value={user.name} onChange={handleChange} placeholder="Enter your last name" />
//             <span id="lnameerr" className="text-danger font-weight-bold"></span>
//           </div>
//           <div className="input-box">
//             <span className="details">Email <span className="text-danger font-weight-bold">*</span></span>
//             <input type="email" name="email" value={user.name} onChange={handleChange} placeholder="Enter your email" />
//             <span id="emailerror" className="text-danger font-weight-bold"></span>
       
//           </div>
//           <div className="input-box">
//             <span className="details">Phone Number<span className="text-danger font-weight-bold">*</span> </span>
//             <input type="phone" name="phone" id="pno" maxlength="13" value={user.name} onChange={handleChange} placeholder="Enter your number" />
//             <span id="perr" className="text-danger font-weight-bold"></span>
//           </div>
//           <div className="input-box">
//             <span className="details">Password <span className="text-danger font-weight-bold">*</span></span>
//             <input type="text" name="password"value={user.name} onChange={handleChange} placeholder="Enter your password" />
//             <span id="passerror" className="text-danger font-weight-bold"></span>
//           </div>
//           <div className="input-box">
//             <span className="details">Confirm Password <span className="text-danger font-weight-bold">*</span></span>
//             <input type="text" name="reEnterPassword" value={user.name} onChange={handleChange} placeholder="Confirm your password" />
//             <span id="cpasserror" className="text-danger font-weight-bold"></span>
//           </div>
//           <div className="input-box">
//             <span className="details">DOB <span className="text-danger font-weight-bold">*</span></span>
//             <input type="date" name="dob" value={user.name} max="2021-12-31" onChange={handleChange} />
//             <span id="dateerror" className="text-danger font-weight-bold"></span>
//           </div>
//           <div className="input-box">
//             <span className="details">Registration number <span className="text-danger font-weight-bold">*</span> </span>
//             <input data-field="phone" name="Regno"  maxlength="15" value={user.name} onChange={handleChange} placeholder="Enter your registration No"/>
//             <span id="Regnoerr" className="text-danger font-weight-bold"></span>
//           </div>
//         </div>
        
//         {/* <div className="gender-details">
//           <input type="radio" name="gender" id="dot-1"/>
//           <input type="radio" name="gender" id="dot-2"/>
//           <input type="radio" name="gender" id="dot-3"/>
//           <span className="gender-title">Gender<span className="text-danger font-weight-bold">*</span></span>
//           <div className="category">
//             <label htmlFor="dot-1">
//             <span className="dot one"  name="Gender" value="male" onChange={handleChange}></span>
//             <span className="gender">Male</span>
//           </label>
//           <label htmlFor="dot-2">
//             <span className="dot two"  name="Gender" value="female"  onChange={handleChange}></span>
//             <span className="gender">Female</span>
//           </label>
//           <label htmlFor="dot-3">
//             <span className="dot three"></span>
//             <span className="gender" name="Gender" value="Ns"  onChange={handleChange} >Prefer not to say</span>
//             </label>
//           </div>
//         </div> */}
//         <div  className="input-box">
//        <input type="radio" name="gender" value="mail"/><span >Male</span>
//        <input type="radio" name="gender" value="Female" /><span >Female</span> 
//           {/* <input type="radio"value="Male"checked={this.state.selectedOption === "Male"}onChange={this.onValueChange}/> */}
//         </div>
//         <div className="button">
//           <input type="button" onClick={handleSubmit} value="Next"/>
//         </div>
//         </div>
//     </div>
//   </div>
//         </div>
//         </form>
//     )

// }

// export default Register









import React, { useState } from "react";
import "./register.css";
import axios from "axios";
// import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import useForm from "../../hooks/useForm";

const Register = () => {
    const formLogin = () => {
      console.log("Callback function when form is submitted!");
      console.log("Form Values ", values);
    };
    const { handleChange, values, errors, handleSubmit } = useForm(formLogin);
    
  return (
    <form onSubmit={handleSubmit} className="form">
      <div className="register">
        <div className="container">
          <div className="title">Doctor Registration</div>
          <div className="content">
            <div className="formm">
              <div className="user-details">
                <div className="input-box">
                  <span className="details">
                    First Name{" "}
                    <span className="text-danger font-weight-bold">*</span>{" "}
                  </span>
                  <input
                    type="text"
                    name="fname"
                    
                    placeholder="Enter your Name"
                    onChange={handleChange}
                    required
                  />
                  <span
                    id="fnameerr"
                    className="text-danger font-weight-bold"
                  ></span>
                  
                </div>
                <div className="input-box">
                  <span className="details">Middle Name</span>
                  <input
                    type="text"
                    name="mname"
                    
                    onChange={handleChange}
                    placeholder="Enter your middle name"
                  />
                </div>
                <div className="input-box">
                  <span className="details">
                    Last Name{" "}
                    <span className="text-danger font-weight-bold">*</span>
                  </span>
                  <input
                    type="text"
                    name="lname"
                    
                    onChange={handleChange}
                    placeholder="Enter your last name"
                  />
                  <span
                    id="lnameerr"
                    className="text-danger font-weight-bold"
                  ></span>
                </div>
                <div className="input-box">
                  <span className="details">
                    Email{" "}
                    <span className="text-danger font-weight-bold">*</span>
                  </span>
                  <input
                    type="email"
                    name="email"
                    onChange={handleChange}
                    placeholder="Enter your email"
                  />
                 {   errors.email && 
                     <span
                    id="passerror"
                    className="text-danger font-weight-bold"
                  >{errors.email}</span>
                  }
                </div>
                <div className="input-box">
                  <span className="details">
                    Phone Number
                    <span className="text-danger font-weight-bold">*</span>{" "}
                  </span>
                  <input
                    type="phone"
                    name="phone"
                    id="pno"
                    maxlength="13"
                    
                    onChange={handleChange}
                    placeholder="Enter your number"
                  />
                   { errors.mobile && 
                     <span
                    id="passerror"
                    className="text-danger font-weight-bold"
                  >{errors.mobile}</span>
                  }
                </div>
                <div className="input-box">
                  <span className="details">
                    Password{" "}
                    <span className="text-danger font-weight-bold">*</span>
                  </span>
                  <input
                    type="password"
                    name="password"
                    
                    onChange={handleChange}
                    placeholder="Enter your password"
                  />
                 {
                     errors.password && 
                     <span
                    id="passerror"
                    className="text-danger font-weight-bold"
                  >{errors.password}</span>
                  }
                </div>
                <div className="input-box">
                  <span className="details">
                    Confirm Password{" "}
                    <span className="text-danger font-weight-bold">*</span>
                  </span>
                  <input
                    type="text"
                    name="reEnterPassword"
                    
                    onChange={handleChange}
                    placeholder="Confirm your password"
                  />
                   {
                     errors.cpassword && 
                     <span
                    id="passerror"
                    className="text-danger font-weight-bold"
                  >{errors.cpassword}</span>
                  }


                </div>
                <div className="input-box">
                  <span className="details">
                    DOB <span className="text-danger font-weight-bold">*</span>
                  </span>
                  <input
                    type="date"
                    name="dob"
                    max="2021-12-31"
                    onChange={handleChange}
                  />
                   {
                     errors.date && 
                     <span
                    id="dateerr"
                    className="text-danger font-weight-bold"
                  >{errors.date}</span>
                  }
                </div>
                <div className="input-box">
                  <span className="details">
                    Registration number{" "}
                    <span className="text-danger font-weight-bold">*</span>{" "}
                  </span>
                  <input
                    data-field="phone"
                    name="Regno"
                    maxlength="15"
                    
                    onChange={handleChange}
                    placeholder="Enter your registration No"
                  />
                  <span
                    id="Regnoerr"
                    className="text-danger font-weight-bold"
                  ></span>
                </div>
              </div>
              <div className="input-box">
                <input type="radio" name="gender" value="mail" />
                <span>Male</span>
                <input type="radio" name="gender" value="Female" />
                <span>Female</span>
                {/* <input type="radio"value="Male"checked={this.state.selectedOption === "Male"}onChange={this.onValueChange}/> */}
              </div>
              <div className="button">
                <input type="button" onClick={handleSubmit} value="Next" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
  }
export default Register;
