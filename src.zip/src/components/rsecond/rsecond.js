import React , {useState} from "react";
import  "./rsecond.css";
import axios from "axios"


const Rsecond=()=>{
    const [user,setUser]=useState({
     
    })

    const handleChange= e => {
        const {name , value} =e.target
        console.log(user)
        setUser({
            ...user,
            [name]:value
        })
    }
    const fileChange1=()=>{
        let files = document.getElementById("myFile1").files;
           if(files.length > 0) {
            // 10 * 1024
           if(files[0].size > 976.5625 * 1024){
            document.getElementById("ferr1").innerHTML="File Size Exceeds 2mb";
               alert("File Size Exceeds 2mb");
           }
          }
          else{
            document.getElementById("ferr1").innerHTML=" ";
          }
        }

        const fileChange2=()=>{
          let files = document.getElementById("myFile2").files;
             if(files.length > 0) {
              // 10 * 1024
             if(files[0].size > 976.5625 * 1024){
              document.getElementById("ferr2").innerHTML="File Size Exceeds 2mb";
                 alert("File Size Exceeds 2mb");
             }
            }
            else{
              document.getElementById("ferr2").innerHTML=" ";
            }
          }

          const fileChange3=()=>{
            let files = document.getElementById("myFile3").files;
               if(files.length > 0) {
                // 10 * 1024
               if(files[0].size > 976.5625 * 1024){
                document.getElementById("ferr3").innerHTML="File Size Exceeds 2mb";
                   alert("File Size Exceeds 2mb");
               }
              }
              else{
                document.getElementById("ferr3").innerHTML=" ";
              }
            }
    
    
    
    const rsecond=()=>{
        const {name, email, password ,reEnterPassword}= user
        
        
      
        
        


            //             // console.log("input",files)
            //             const fsize = files.size;
            //             console.log("size",fsize)
            //     const file = Math.round((fsize / 1024));
            //     let span = document.getElementById("ferr")
            //   if(files){
            // //       let files = input.files;
                  
            //        if(files.length > 0) {
            //          if(files[0].size > 10 * 1024){
            //            span.innerText = 'File Size Exceeds 10kb';
            //             return;
            //         }
            //        }
            //     }

        if(name && email && password && (password === reEnterPassword))
        {
            if(password.length<8){
                alert("please enter at lest 8 word password")
            }else{
            axios.post("http://localhost:9002/register",{user})
            .then( res=> alert(res.data.message))
            }
        }
        else{
            alert("invalid input")
        }
    }
    return(
       <div className="register">
  <div className="container">
    <div className="title">Doctor Registration</div>
    <div className="content">
      <div className="formm">
        <div className="user-details">
          <div className="input-box">
            <span className="details">Qualification:</span>
                <select id="qualification"  name="qualification">
                    <option value="MBBS">MBBS</option>
                    <option value="sMDaab">MD</option>
                    <option value="MS">MS</option>
                    <option value="DM">DM</option>
                    <option value="MCH">MCH</option>
                    <option value="DNB">DNB</option>
                    <option value="DNB">Non of thease</option>
                </select>
            {/* <input type="" name="fname" value={user.name} placeholder="Enter your Name" onChange={handleChange} required/> */}
          </div>
          <div className="input-box">
            <span className="details">Specialization</span>
                <select id="specialization"  name="specialization">
                    <option value="Medicine">Medicine</option>
                    <option value="Surgery">Surgery</option>
                    <option value="Gynecology">Gynecology</option>
                    <option value="Ophthalmology">Ophthalmology</option>
                    <option value="Orthopedics">Orthopedics</option>
                </select>
          </div>
          <div className="input-box">
            <span className="details">Registration Certificate</span>
            <input type="file" id="myFile1" onChange={fileChange1} name="filename"  placeholder="Enter your email"/>
            <span id="ferr1" className="text-danger font-weight-bold"></span>
          </div>
          <div className="input-box">
            <span className="details">Renewal Of Registration</span>
            <input type="file" id="myFile2" onChange={fileChange2} name="filename"  placeholder="Enter your email" required/>
            <span id="ferr2" className="text-danger font-weight-bold"></span>
          </div>
          <div className="input-box">
            <span className="details">Hospital / Clinic Name </span>
            <input type="text" name="hname" value={user.name} onChange={handleChange} placeholder="Enter your Hospital or Clinic Name" required/>
          </div>
          <div className="input-box">
            <span className="details">Hospital / Clinic Address </span>
            <input type="text" name="haddress" value={user.name} onChange={handleChange} placeholder="Enter your Hospital or Clinic Address" required/>
          </div>
          <div className="input-box">
            <span className="details">Upload Profile Picture </span>
            <input type="file" id="myFile3" name="filename"  onChange={fileChange3} placeholder="Enter your file" />
            <span id="ferr3" className="text-danger font-weight-bold"></span>
          </div>
        </div>
        <div className="button">
          <input type="button" onClick={rsecond} value="Sign Up"/>
        </div>
        <div className="signup-link">Already a member? <a  >Login now</a></div>
        </div>
    </div>
  </div>
        </div>
    )

}

export default Rsecond
